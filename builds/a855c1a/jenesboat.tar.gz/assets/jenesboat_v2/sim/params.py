"""Fundamental parameters: every tunable of the simulation in one place.

Units are SI throughout the sim: metres, seconds, m/s, degrees clockwise from north.  Knots
and kilometres appear only in the HUD and in the docs.  ``docs/PARAMETERS.md`` explains each
value and where it comes from; change numbers here, not in the modules that use them.
"""

from __future__ import annotations

from dataclasses import dataclass, replace

KNOT = 0.514444  # metres per second
HOUR = 3600.0

# Engine telegraph: the propeller orders the player steps through, as throttle fractions.
TELEGRAPH: tuple[tuple[str, float], ...] = (
    ("ASTERN FULL", -1.0),
    ("ASTERN HALF", -0.5),
    ("STOP", 0.0),
    ("AHEAD SLOW", 0.25),
    ("AHEAD HALF", 0.5),
    ("AHEAD FULL", 0.75),
    ("AHEAD FLANK", 1.0),
)
TELEGRAPH_STOP = 2  # index of STOP
RUDDER_MAX_ANGLE = 35.0  # degrees at full rudder (display only; the sim uses -1..1)
RUDDER_RATE = 0.5  # rudder units per second while A/D is held (hard over in 2 s)


@dataclass(frozen=True)
class VesselParams:
    """Classic ship maneuvering: propeller sets speed with inertia, rudder turns on a radius."""

    max_speed: float  # m/s, full ahead
    acceleration: float = 0.3  # m/s^2 toward the ordered speed
    turn_radius: float = 300.0  # m, radius of the circle steamed at full rudder
    max_turn_rate: float = 4.0  # deg/s, cap so fast ships do not spin
    reverse_fraction: float = 0.5  # max astern speed as a fraction of max_speed
    length: float = 60.0  # metres (hull box and hit test)
    beam: float = 8.0  # metres (hull box and hit test)


@dataclass(frozen=True)
class TorpedoParams:
    name: str
    speed: float  # m/s
    max_run: float  # m, the torpedo sinks after this run
    arm_distance: float  # m, no detonation closer than this to the tube
    tubes: int  # bow tubes, each holds one torpedo
    reserves: int  # torpedoes stowed for reloading
    reload_time: float  # s, to reload one tube
    wake_visible_range: float  # m, how far lookouts see its track (0 = wakeless)


@dataclass(frozen=True)
class DeckGunParams:
    """Defined for the parameter sheet; firing the gun is a Milestone 2 feature."""

    name: str
    calibre_mm: float
    max_range: float  # m
    rate: float  # s between rounds
    rounds: int
    hits_per_freighter: int  # rounds needed to sink a freighter


@dataclass(frozen=True)
class SubmarineParams:
    vessel: VesselParams  # surfaced kinematics
    submerged_speed: float  # m/s, electric motors
    periscope_depth: float  # m
    deep_depth: float  # m, the "go deep" order
    max_depth: float  # m
    dive_rate: float  # m/s vertical
    fire_max_depth: float  # m, tubes can be fired at or above this depth
    battery_full_speed_hours: float  # endurance at full submerged speed
    battery_creep_hours: float  # endurance with motors nearly stopped
    recharge_hours: float  # surfaced, diesels charging
    battery_empty_speed_fraction: float  # of submerged speed once the battery is flat
    lookout_range: float  # m, surfaced, daylight, big merchant with smoke
    periscope_range: float  # m, at periscope depth
    periscope_band: float  # m, periscope usable while depth <= periscope_depth + band
    hydrophone_range: float  # m, bearing-only contacts
    hydrophone_min_depth: float  # m, hydrophones useless on the surface
    hydrophone_max_speed: float  # m/s, own noise masks contacts above this
    scope_raise_time: float = 5.0  # s from the order to the periscope being up
    overdepth_rate: float = 0.001  # hull damage per second for every 20 m below the safe depth


@dataclass(frozen=True)
class ShipType:
    name: str
    kind: str  # "merchant" or "military"
    vessel: VesselParams
    cruise_speed: float  # m/s, economical speed on the route
    tonnage: int  # GRT, the score for sinking it
    hits_to_sink: int  # torpedo hits
    visibility: float  # multiplier on how far the sub sees it (size, smoke)
    lookout: float  # multiplier on how far it sees the sub


@dataclass(frozen=True)
class DetectionParams:
    """How a ship's lookouts see the submarine (daylight; multiply by ``light`` at night)."""

    surfaced_range: float  # m, a surfaced boat
    periscope_range: float  # m, a periscope at quiet speed
    periscope_quiet_speed: float  # m/s, above this the feather and wake grow
    periscope_speed_penalty: float  # m of extra detection range per m/s above quiet speed
    periscope_max_depth: float  # m, deeper than this the boat is invisible
    spot_time: float  # s the boat must stay in range before the ship reacts


@dataclass(frozen=True)
class MerchantAIParams:
    alert_duration: float  # s of running after the last sighting
    zigzag_angle: float  # deg either side of the escape course
    zigzag_period: float  # s per leg
    spread_angle: float  # deg between neighbours so a group fans out
    escape_range: float  # m from the boat at which an alerted merchant counts as escaped
    panic_range: float  # m, a torpedo hit alerts merchants within this distance


@dataclass(frozen=True)
class SonarParams:
    """A destroyer's active sonar (ASDIC).  One ping gives one *effective reach*:

        R_eff = range x f_aspect x f_speed x f_layer x f_set   (0 in a noise shadow)

    the range at which this ship can hold this boat right now; an echo comes back inside it
    (outside the blind zone under the keel and the arc the set can be trained over), surely
    inside ``sure_fraction`` of it and with a chance falling to zero at its edge.  The fix is
    a random point in a ring whose radius grows as the echo gets fainter."""

    range: float  # m, a beam-on moving boat above the layer, settled set
    arc: float  # deg either side of the bow the set can be trained; the rest is the baffles
    min_range: float  # m, floor of the blind zone under the keel
    depth_blind_ratio: float  # the echo is lost inside depth x ratio (the beam cannot tilt down)
    blind_zone_cap: float  # m, the blind zone never exceeds this
    own_noise_speed: float  # m/s, faster than this the ship's own screws deafen the set
    own_noise_factor: float  # reach multiplier while faster than that (f_set, sprinting)
    settle_time: float  # s after slowing below own_noise_speed before the set hears again
    turn_factor: float  # reach multiplier while the rudder is more than half over (f_set)
    quiet_speed: float  # m/s, a boat creeping at or below this is harder to hear
    quiet_factor: float  # reach multiplier for a creeping boat (f_speed)
    aspect_floor: float  # f_aspect = floor + (1 - floor) x |sin aspect|: end-on gives the floor
    layer_factor: float  # reach multiplier when the boat is below the thermocline (f_layer)
    sure_fraction: float  # a ping inside this fraction of R_eff is a sure echo
    area_base: float  # m, radius of the fix's ring at zero range
    area_span: float  # m, ring radius added per unit of d / R_eff (175 m at the edge of 3 km)
    noise_base: float  # m, noise radius of a stopped or sunk friendly ship (its shadow)
    noise_per_knot: float  # m of noise radius per knot of that ship's speed
    cloud_radius: float  # m, the noise shadow a pattern's bursts leave in the water
    cloud_duration: float  # s the cloud lasts
    ping_interval: float  # s between pings; the fix is as old as the last ping


@dataclass(frozen=True)
class DepthChargeParams:
    sink_rate: float  # m/s, how fast a charge sinks to its set depth
    lethal_radius: float  # m, a burst this close breaks the boat
    damage_radius: float  # m, a burst this close hurts the boat
    damage: float  # hull damage (0..1; the boat is lost at 1) at the edge of damage_radius
    bands: tuple[tuple[float, float], ...]  # m, the depth bands a pattern is set in, search order
    confirm_damage: float  # a pattern doing at least this much confirms its band; less moves on
    pattern_size: int  # charges per attack run, spread over the band and thrown to both sides
    drop_interval: float  # s between charges in a pattern
    throw_range: float  # m, projectors throw a charge up to this far from the ship
    scatter: float  # m, each charge lands up to this far either side of the predicted path
    pattern_cooldown: float  # s before the same ship starts another run (the rack reload)
    run_max_time: float  # s, a run whose aim points the ship cannot reach is abandoned
    magazine: int  # charges carried per destroyer


@dataclass(frozen=True)
class TorpedoEvasionParams:
    """How an escort notices a running torpedo and gets out of its way (the ``comb`` strategy
    of the ``escort_evade`` slot, ``sim/escort.py``)."""

    hear_range: float  # m, a running torpedo's screws are heard this far on the hydrophones
    reaction_time: float  # s between hearing it and the helm answering
    threat_width: float  # m, a torpedo that will pass closer than this is dodged
    comb_angle: float  # deg off the torpedo's course the ship steers to open the distance


@dataclass(frozen=True)
class TorpedoHitParams:
    """What happens when a torpedo reaches a hull.  Early-war contact pistols failed at
    grazing angles: a torpedo meeting the hull nearly along the ship's axis (bow-on or
    stern-on) is a glancing blow that may not detonate."""

    glance_angle: float  # deg off the ship's axis below which the hit is a glancing blow
    glance_chance: float  # 0..1, the chance a glancing blow still detonates


@dataclass(frozen=True)
class EscortAIParams:
    hunters_per_escort: int  # one hunter per this many escorts (at least one), max_hunters cap
    max_hunters: int
    track_window: float  # s of sonar fixes used to estimate the boat's course and speed
    track_min_baseline: float  # s, fixes closer in time than this give no course estimate
    max_track_speed: float  # m/s, a faster estimate is noise (the boat's best submerged speed)
    lead_limit: float  # s, the prediction is never carried further than this past the last fix
    lose_track_time: (
        float  # s without a fix, counted from the hunter's arrival, before standing down
    )
    datum_attack_age: (
        float  # s, a hunter still attacks the dead-reckoned position with a fix this old
    )
    blind_lead_speed: float  # m/s, the straight flight assumed after a datum attack finds nothing
    blind_attacks: int  # how many attacks on the assumed flight before the hunter gives it up
    hunt_leash: float  # m from the convoy centre a hunter will not follow the boat beyond
    max_hunt_time: float  # s after the alarm the escorts give the hunt up
    station_ahead: float  # m, formation station ahead of the convoy centre
    station_abeam: float  # m, formation station abeam of the convoy centre (alternating sides)
    screen_distance: float  # m from the convoy centre toward the threat
    screen_abeam: float  # m between screening ships
    station_tolerance: float  # m, within this the ship holds course at convoy speed
    attack_speed: float  # m/s, hunting speed (sonar is degraded above own_noise_speed)
    approach_range: float  # m from the datum where a hunter slows so its sonar can hear
    approach_speed: float  # m/s, the closing speed inside approach_range
    search_speed: float  # m/s, speed while searching the datum area
    search_start: float  # m, first search circle radius around the datum
    search_growth: float  # m/s, how fast the circle widens as the track gets older
    search_max: float  # m
    shelter_distance: float  # m behind the screening ship that merchants run to
    shelter_radius: float  # m, merchants this near the shelter point stop closing in


@dataclass(frozen=True)
class SeaParams:
    """The water of one hunt: a thermocline (temperature layer) that bends sound away, so a
    boat below it gives a weaker echo.  Its depth is drawn per hunt from the seed."""

    layer_min: float  # m, the layer is no shallower than this
    layer_max: float  # m, and no deeper
    layer_chance: float  # 0..1, the chance a hunt has a layer at all


@dataclass(frozen=True)
class RadarParams:
    """Surface-search radar on the escorts: detects surfaced vessels only, exactly, and is
    handled like a sighting.  ``range`` 0 means no radar at this level."""

    range: float  # m


# --- vessels -------------------------------------------------------------------------------

TYPE_VIIC_SURFACED = VesselParams(
    max_speed=17.7 * KNOT,
    acceleration=0.2,
    turn_radius=140.0,
    max_turn_rate=4.0,
    reverse_fraction=0.4,
    length=67.0,
    beam=6.2,
)

TYPE_VIIC = SubmarineParams(
    vessel=TYPE_VIIC_SURFACED,
    submerged_speed=7.6 * KNOT,
    periscope_depth=12.0,
    deep_depth=60.0,
    max_depth=150.0,
    dive_rate=1.0,
    fire_max_depth=20.0,
    battery_full_speed_hours=1.5,
    battery_creep_hours=20.0,
    recharge_hours=3.0,
    battery_empty_speed_fraction=0.15,
    lookout_range=12_000.0,
    periscope_range=7_000.0,
    periscope_band=2.0,
    hydrophone_range=15_000.0,
    hydrophone_min_depth=11.0,
    hydrophone_max_speed=4.0 * KNOT,
)

FREIGHTER = ShipType(
    name="freighter",
    kind="merchant",
    vessel=VesselParams(
        max_speed=11.0 * KNOT,
        acceleration=0.08,
        turn_radius=350.0,
        max_turn_rate=2.0,
        length=120.0,
        beam=16.0,
    ),
    cruise_speed=8.0 * KNOT,
    tonnage=4_500,
    hits_to_sink=1,
    visibility=1.0,
    lookout=1.0,
)

TANKER = ShipType(
    name="tanker",
    kind="merchant",
    vessel=VesselParams(
        max_speed=10.0 * KNOT,
        acceleration=0.06,
        turn_radius=450.0,
        max_turn_rate=1.5,
        length=160.0,
        beam=21.0,
    ),
    cruise_speed=8.0 * KNOT,
    tonnage=9_000,
    hits_to_sink=2,
    visibility=1.15,
    lookout=1.0,
)

DESTROYER = ShipType(
    name="destroyer",
    kind="military",
    vessel=VesselParams(
        max_speed=32.0 * KNOT,
        acceleration=0.5,
        turn_radius=250.0,
        max_turn_rate=6.0,
        length=100.0,
        beam=10.0,
    ),
    cruise_speed=12.0 * KNOT,
    tonnage=1_800,
    hits_to_sink=1,
    visibility=0.8,
    lookout=1.5,
)

SHIP_TYPES: dict[str, ShipType] = {t.name: t for t in (FREIGHTER, TANKER, DESTROYER)}

# --- weapons -------------------------------------------------------------------------------

G7E = TorpedoParams(
    name="G7e",
    speed=30.0 * KNOT,
    max_run=5_000.0,
    arm_distance=300.0,
    tubes=4,
    reserves=8,
    reload_time=120.0,
    wake_visible_range=0.0,
)

G7A = TorpedoParams(
    name="G7a",
    speed=40.0 * KNOT,
    max_run=6_000.0,
    arm_distance=300.0,
    tubes=4,
    reserves=8,
    reload_time=120.0,
    wake_visible_range=1_500.0,
)

DECK_GUN_88 = DeckGunParams(
    name="8.8 cm SK C/35",
    calibre_mm=88.0,
    max_range=4_000.0,
    rate=6.0,
    rounds=200,
    hits_per_freighter=12,
)

SONAR_ASDIC = SonarParams(
    range=3_000.0,
    arc=70.0,
    min_range=150.0,
    depth_blind_ratio=3.0,
    blind_zone_cap=300.0,
    own_noise_speed=15.0 * KNOT,
    own_noise_factor=0.25,
    settle_time=20.0,
    turn_factor=0.5,
    quiet_speed=2.5 * KNOT,
    quiet_factor=0.7,
    aspect_floor=0.4,
    layer_factor=0.5,
    sure_fraction=0.4,
    area_base=25.0,
    area_span=150.0,
    noise_base=150.0,
    noise_per_knot=30.0,
    cloud_radius=150.0,
    cloud_duration=180.0,
    ping_interval=5.0,
)

SEA = SeaParams(layer_min=40.0, layer_max=90.0, layer_chance=1.0)

RADAR_NONE = RadarParams(range=0.0)
RADAR_SURFACE_SEARCH = RadarParams(range=20_000.0)

TORPEDO_EVASION = TorpedoEvasionParams(
    hear_range=1_200.0,
    reaction_time=5.0,
    threat_width=150.0,
    comb_angle=30.0,
)

TORPEDO_HIT = TorpedoHitParams(
    glance_angle=30.0,
    glance_chance=0.5,
)

DEPTH_CHARGE = DepthChargeParams(
    sink_rate=3.0,
    lethal_radius=12.0,
    damage_radius=45.0,
    damage=0.4,
    bands=((15.0, 40.0), (40.0, 80.0), (80.0, 150.0)),
    confirm_damage=0.10,
    pattern_size=6,
    drop_interval=1.0,
    throw_range=150.0,
    scatter=15.0,
    pattern_cooldown=120.0,
    run_max_time=90.0,
    magazine=40,
)

# --- rules ---------------------------------------------------------------------------------

DETECTION = DetectionParams(
    surfaced_range=6_000.0,
    periscope_range=1_000.0,
    periscope_quiet_speed=3.0 * KNOT,
    periscope_speed_penalty=900.0,
    periscope_max_depth=14.0,
    spot_time=3.0,
)

MERCHANT_AI = MerchantAIParams(
    alert_duration=600.0,
    zigzag_angle=30.0,
    zigzag_period=90.0,
    spread_angle=20.0,
    escape_range=20_000.0,
    panic_range=6_000.0,
)

ESCORT_AI = EscortAIParams(
    hunters_per_escort=3,
    max_hunters=2,
    track_window=45.0,
    track_min_baseline=10.0,
    max_track_speed=7.6 * KNOT,
    lead_limit=90.0,
    lose_track_time=300.0,
    datum_attack_age=180.0,
    blind_lead_speed=7.0 * KNOT,
    blind_attacks=2,
    hunt_leash=10_000.0,
    max_hunt_time=1_800.0,
    station_ahead=1_200.0,
    station_abeam=1_500.0,
    screen_distance=2_000.0,
    screen_abeam=700.0,
    station_tolerance=250.0,
    attack_speed=20.0 * KNOT,
    approach_range=1_500.0,
    approach_speed=14.0 * KNOT,
    search_speed=12.0 * KNOT,
    search_start=400.0,
    search_growth=1.0,
    search_max=2_500.0,
    shelter_distance=700.0,
    shelter_radius=400.0,
)


# --- difficulty levels ---------------------------------------------------------------------
# A difficulty (cadet, patrol, veteran) is plain data: the parameter blocks above, bundled,
# with whole blocks swapped for ``replace`` copies, plus the name of the strategy filling
# each AI slot.  The plug-in mechanism (registering strategies, looking them up, checking a
# difficulty) is ``sim/difficulty.py``; the design is explained in ``docs/DIFFICULTY.md``.


@dataclass(frozen=True)
class ScenarioParams:
    """What the hunting scenario puts on the map besides the three merchants."""

    escorts: int  # destroyers with the group


SCENARIO = ScenarioParams(escorts=2)


@dataclass(frozen=True)
class Rules:
    """The complete parameter set one hunt runs on.  The world carries one and every module
    reads its numbers from ``world.rules``; the defaults are the sheet above."""

    submarine: SubmarineParams = TYPE_VIIC
    torpedo: TorpedoParams = G7E
    detection: DetectionParams = DETECTION
    merchant_ai: MerchantAIParams = MERCHANT_AI
    sonar: SonarParams = SONAR_ASDIC
    depth_charge: DepthChargeParams = DEPTH_CHARGE
    escort_ai: EscortAIParams = ESCORT_AI
    evasion: TorpedoEvasionParams = TORPEDO_EVASION
    torpedo_hit: TorpedoHitParams = TORPEDO_HIT
    scenario: ScenarioParams = SCENARIO
    sea: SeaParams = SEA
    radar: RadarParams = RADAR_NONE


@dataclass(frozen=True)
class Strategies:
    """Which behaviour fills each AI decision point (a *slot*).  Each value names a strategy
    registered in ``sim/difficulty.py``; the defaults are the M1/M2 behaviours."""

    escort_search: str = "sweep"  # how a hunter looks for a boat whose track has gone stale
    escort_evade: str = "none"  # what an escort does about a torpedo running at it (comb: dodge)
    merchant_flee: str = "zigzag"  # how an alerted merchant runs


@dataclass(frozen=True)
class Difficulty:
    """A difficulty level (not a game level: there is one hunt, played harder or easier)."""

    name: str  # the id used on the command line, the URL and in events
    title: str  # what the HUD shows
    description: str  # one line for --help and the docs
    rules: Rules
    strategies: Strategies


CADET = Difficulty(
    name="cadet",
    title="Cadet",
    description="one destroyer with a short sonar, a narrow cone and a short memory that never "
    "dodges, lighter charges, quick reloads, every hit counts",
    rules=Rules(
        submarine=replace(TYPE_VIIC, overdepth_rate=0.0005),
        torpedo=replace(G7E, reload_time=90.0),
        sonar=replace(
            SONAR_ASDIC,
            range=2_400.0,
            arc=45.0,
            depth_blind_ratio=4.0,
            aspect_floor=0.3,
            layer_factor=0.4,
            cloud_duration=240.0,
        ),
        depth_charge=replace(DEPTH_CHARGE, damage=0.3, pattern_cooldown=150.0),
        escort_ai=replace(
            ESCORT_AI,
            lose_track_time=180.0,
            datum_attack_age=120.0,
            blind_attacks=1,
            hunt_leash=6_000.0,
            max_hunt_time=900.0,
        ),
        torpedo_hit=replace(TORPEDO_HIT, glance_chance=1.0),
        scenario=ScenarioParams(escorts=1),
    ),
    strategies=Strategies(escort_evade="none"),
)

PATROL = Difficulty(
    name="patrol",
    title="Patrol",
    description="two destroyers that dodge torpedoes, the base sheet (the default)",
    rules=Rules(),
    strategies=Strategies(escort_evade="comb"),
)

VETERAN = Difficulty(
    name="veteran",
    title="Veteran",
    description="three destroyers with longer sonar reach, a wide cone, radar and a long memory "
    "that dodge torpedoes, heavier charges, slow reloads, glancing hits rarely detonate",
    rules=Rules(
        submarine=replace(TYPE_VIIC, overdepth_rate=0.0015),
        torpedo=replace(G7E, reload_time=150.0),
        sonar=replace(
            SONAR_ASDIC,
            range=3_600.0,
            arc=90.0,
            depth_blind_ratio=2.5,
            aspect_floor=0.5,
            layer_factor=0.6,
            sure_fraction=0.5,
            cloud_duration=120.0,
        ),
        depth_charge=replace(DEPTH_CHARGE, damage=0.5, lethal_radius=15.0, pattern_cooldown=90.0),
        escort_ai=replace(
            ESCORT_AI,
            lose_track_time=480.0,
            datum_attack_age=240.0,
            blind_attacks=3,
            hunt_leash=15_000.0,
            max_hunt_time=3_600.0,
        ),
        torpedo_hit=replace(TORPEDO_HIT, glance_chance=0.25),
        scenario=ScenarioParams(escorts=3),
        sea=replace(SEA, layer_chance=0.7),
        radar=RADAR_SURFACE_SEARCH,
    ),
    strategies=Strategies(escort_evade="comb"),
)

DIFFICULTIES: dict[str, Difficulty] = {d.name: d for d in (CADET, PATROL, VETERAN)}
DEFAULT_DIFFICULTY = PATROL.name
