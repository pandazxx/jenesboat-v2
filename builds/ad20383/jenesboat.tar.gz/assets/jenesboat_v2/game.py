"""Frontend-agnostic game session: turns control intents into orders and ticks the world.

The session owns the things a frontend needs that are not physics: time compression, the
map zoom, the message log, the selected target and its fire-control solution, and the
restart.  It never imports raylib.
"""

from __future__ import annotations

import math
import random
from dataclasses import dataclass

from jenesboat_v2 import events
from jenesboat_v2.sim import World, hunting_scenario
from jenesboat_v2.sim.detection import VISUAL, Contact
from jenesboat_v2.sim.weapons import Solution, solution

THROTTLE_RAMP = 0.5  # throttle units per second while W/S is held
TIME_SCALES = (1, 2, 4, 8)
ZOOM_LEVELS = (2.0, 5.0, 10.0, 20.0, 40.0)  # metres per pixel
DEFAULT_ZOOM = 3  # index: 20 m/px, about 19 km across a 960 px window
MAX_SUBSTEP = 0.1  # s of sim time per physics step
MESSAGE_LIMIT = 6


@dataclass
class Controls:
    """What the player is doing this frame.  Held keys are levels, the rest are edges."""

    throttle_up: bool = False
    throttle_down: bool = False
    port: bool = False
    starboard: bool = False
    dive_toggle: bool = False
    deep: bool = False
    fire: bool = False
    zoom_in: bool = False
    zoom_out: bool = False
    time_scale: int | None = None  # one of TIME_SCALES: switch to that compression
    restart: bool = False


class Game:
    def __init__(
        self,
        world: World | None = None,
        state_interval: float = 1.0,
        seed: int | None = None,
    ) -> None:
        self.state_interval = state_interval
        self.seed = seed if seed is not None else random.randrange(1_000_000)
        self.world = world if world is not None else hunting_scenario(self.seed)
        self._since_state = 0.0
        self.state_events = 0
        self.time_scale = TIME_SCALES[0]
        self.zoom_index = DEFAULT_ZOOM
        self.messages: list[tuple[float, str]] = []
        self.restarts = 0
        self._drain()

    # --- orders ----------------------------------------------------------------------------

    def apply(self, controls: Controls, dt: float) -> None:
        if controls.restart:
            self.restart()
            return
        sub = self.world.player
        if controls.throttle_up:
            sub.set_throttle(sub.throttle + THROTTLE_RAMP * dt)
        if controls.throttle_down:
            sub.set_throttle(sub.throttle - THROTTLE_RAMP * dt)
        rudder = 0.0
        if controls.port:
            rudder -= 1.0
        if controls.starboard:
            rudder += 1.0
        sub.set_rudder(rudder)
        if controls.dive_toggle:
            sub.toggle_dive()
        if controls.deep:
            sub.order_deep()
        if controls.fire:
            self.fire()
        if controls.zoom_in:
            self.zoom_index = max(0, self.zoom_index - 1)
        if controls.zoom_out:
            self.zoom_index = min(len(ZOOM_LEVELS) - 1, self.zoom_index + 1)
        if controls.time_scale is not None:
            self.set_time_scale(controls.time_scale)

    def fire(self) -> bool:
        torpedo = self.world.fire()
        self._drain()
        return torpedo is not None

    def set_time_scale(self, scale: int) -> None:
        """Switch to one of ``TIME_SCALES``; anything else is ignored."""
        if scale in TIME_SCALES:
            self.time_scale = scale

    def restart(self, seed: int | None = None) -> None:
        self.restarts += 1
        self.seed = seed if seed is not None else self.seed + 1
        self.world = hunting_scenario(self.seed)
        self.messages.clear()
        self._since_state = 0.0
        events.emit("restart", seed=self.seed)
        self._drain()

    # --- time ------------------------------------------------------------------------------

    @property
    def zoom(self) -> float:
        return ZOOM_LEVELS[self.zoom_index]

    def update(self, dt: float) -> None:
        """Advance the game by ``dt`` real seconds (times the time compression)."""
        remaining = dt * self.time_scale
        while remaining > 1e-9:
            step = min(MAX_SUBSTEP, remaining)
            self.world.step(step)
            remaining -= step
        self._drain()
        self._since_state += dt * self.time_scale
        if self._since_state >= self.state_interval - 1e-9:
            self._since_state = 0.0
            self.emit_state()

    def _drain(self) -> None:
        """Publish the world's pending events and keep the human-readable ones as messages."""
        for ev in self.world.events:
            data = dict(ev)
            name = data.pop("event")
            t = data.pop("t", self.world.time)
            events.emit(name, t=t, **data)
            text = describe(name, data)
            if text:
                self.messages.append((t, text))
        self.world.events.clear()
        del self.messages[:-MESSAGE_LIMIT]

    # --- what the HUD shows ----------------------------------------------------------------

    def target(self) -> Contact | None:
        """The visual contact nearest the boat (the one the fire-control helper tracks)."""
        visual = [c for c in self.world.contacts if c.method == VISUAL]
        if not visual:
            return None
        return min(visual, key=lambda c: c.range or math.inf)

    def solution(self) -> Solution | None:
        target = self.target()
        sub = self.world.player
        if target is None or target.x is None:
            return None
        return solution(
            sub.x,
            sub.y,
            sub.heading,
            sub.tubes.params,
            target.x,
            target.y,
            target.heading or 0.0,
            target.speed or 0.0,
        )

    def snapshot(self) -> dict:
        data = self.world.snapshot()
        data["seed"] = self.seed
        data["time_scale"] = self.time_scale
        data["zoom"] = self.zoom
        sol = self.solution()
        data["solution"] = sol.snapshot() if sol else None
        target = self.target()
        data["target"] = target.ship_id if target else None
        return data

    def emit_state(self) -> None:
        self.state_events += 1
        events.emit("state", **self.snapshot())


def describe(name: str, data: dict) -> str | None:
    """One HUD line per event worth telling the player about."""
    if name == "intel":
        return (
            f"BdU: {data['ships']} merchants reported bearing {data['bearing']:03d}, "
            f"{data['range'] / 1000:.0f} km, course ~{data['course']:03d}"
        )
    if name == "contact":
        how = "hydrophone bearing" if data["method"] == "hydrophone" else "sighted"
        return f"{data['ship']}: {how} {data['bearing']:03.0f}"
    if name == "contact_lost":
        return f"{data['ship']}: contact lost"
    if name == "alert":
        why = "we were sighted" if data["reason"] == "sighted" else "torpedo"
        return f"{', '.join(data['ships'])} running: {why}"
    if name == "fire":
        return f"torpedo {data['torpedo']} away, course {data['heading']:03.0f}"
    if name == "fire_refused":
        return "cannot fire: " + ("too deep" if data["reason"] == "deep" else "tubes empty")
    if name == "hit":
        return f"HIT {data['ship']}"
    if name == "sunk":
        return f"{data['ship']} SUNK, {data['tonnage']:,} GRT"
    if name == "torpedo_lost":
        return f"torpedo {data['torpedo']} missed"
    if name == "escaped":
        return f"{data['ship']} got away"
    if name == "mission_end":
        return (
            f"mission over: {len(data['sunk'])} sunk ({data['tonnage']:,} GRT), "
            f"{len(data['escaped'])} escaped"
        )
    return None
